angular.module('myApp')
    .constant("BASEURL", "http://localhost:3000");