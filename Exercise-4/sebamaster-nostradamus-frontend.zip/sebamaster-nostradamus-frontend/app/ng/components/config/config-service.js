/**
 * One can implmenet a config service if configuration more complex than constants is required
 */